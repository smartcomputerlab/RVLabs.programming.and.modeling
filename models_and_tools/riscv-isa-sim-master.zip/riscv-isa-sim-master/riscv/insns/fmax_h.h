require_either_extension(EXT_ZFH, EXT_ZHINX);
require_fp;
WRITE_FRD_H(f16_max(FRS1_H, FRS2_H));
set_fp_exceptions;
