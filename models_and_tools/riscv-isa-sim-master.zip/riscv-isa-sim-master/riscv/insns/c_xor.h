require_extension(EXT_ZCA);
WRITE_RVC_RS1S(RVC_RS1S ^ RVC_RS2S);
