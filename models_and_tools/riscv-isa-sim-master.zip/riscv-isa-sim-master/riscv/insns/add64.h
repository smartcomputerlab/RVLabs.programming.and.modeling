P_64_PROFILE({
  rd = rs1 + rs2;
})
