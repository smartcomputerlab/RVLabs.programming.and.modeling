require_extension('F');
require_extension(EXT_ZFA);
require_fp;
WRITE_FRD_F(f32_roundToInt(FRS1_F, RM, false));
set_fp_exceptions;
