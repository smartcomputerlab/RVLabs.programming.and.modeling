require_extension(EXT_ZCB);
require_extension(EXT_ZBA);
require_rv64;
WRITE_RVC_RS1S((reg_t)(uint32_t)(RVC_RS1S));
