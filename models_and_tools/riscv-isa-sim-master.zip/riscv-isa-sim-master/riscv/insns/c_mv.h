require_extension(EXT_ZCA);
require(insn.rvc_rs2() != 0);
WRITE_RD(RVC_RS2);
