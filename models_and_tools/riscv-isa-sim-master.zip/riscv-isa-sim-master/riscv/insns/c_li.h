require_extension(EXT_ZCA);
WRITE_RD(insn.rvc_imm());
