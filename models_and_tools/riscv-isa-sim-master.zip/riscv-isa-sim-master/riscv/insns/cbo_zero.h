require_extension(EXT_ZICBOZ);
DECLARE_XENVCFG_VARS(CBZE);
require_envcfg(CBZE);
MMU.cbo_zero(RS1);
