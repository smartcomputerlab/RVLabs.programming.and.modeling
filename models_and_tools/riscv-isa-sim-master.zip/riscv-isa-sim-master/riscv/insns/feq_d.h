require_either_extension('D', EXT_ZDINX);
require_fp;
WRITE_RD(f64_eq(FRS1_D, FRS2_D));
set_fp_exceptions;
