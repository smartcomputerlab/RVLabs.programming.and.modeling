require_either_extension(EXT_ZFH, EXT_ZHINX);
require_fp;
softfloat_roundingMode = RM;
WRITE_FRD_H(f16_add(FRS1_H, FRS2_H));
set_fp_exceptions;
