require_extension(EXT_ZBPBO);
WRITE_RD((RS1 & RS2) | (RS3 & ~RS2));
