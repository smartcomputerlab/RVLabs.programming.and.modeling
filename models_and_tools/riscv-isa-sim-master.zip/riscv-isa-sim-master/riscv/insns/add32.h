require_rv64;
P_LOOP(32, {
  pd = ps1 + ps2;
})
