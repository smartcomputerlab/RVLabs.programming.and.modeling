P_LOOP(8, {
  pd = ps1 + ps2;
})
