require_extension(EXT_ZCB);
require_extension(EXT_ZBB);
WRITE_RVC_RS1S((reg_t)(uint16_t)(RVC_RS1S));
